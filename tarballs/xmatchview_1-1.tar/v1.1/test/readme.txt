
This test folder is provided to test your installation.

To test it, please run:

./runXMV-conifer.sh FTL1_ss.fa_vs_FTL1_pa.fa.rep FTL1_ss.fa FTL1_pa.fa 200 10 1 FTL1_ss.txt FTL1_pa.txt

and

./runXMV.sh FTL1_ss.fa_vs_FTL1_pa.fa.rep FTL1_ss.fa FTL1_pa.fa 200 10 1 FTL1_ss.txt FTL1_pa.txt

at the unix prompt.  If the install is successful, you should have generated two png files:

xmv-conifer_FTL1_ss.fa_vs_FTL1_pa.fa.rep_m10_b10_r1_c2.png
xmv_FTL1_ss.fa_vs_FTL1_pa.fa.rep_m10_r10_l1_c1.png

You could compare the results to:

xmv-conifer_FTL1_ss.fa_vs_FTL1_pa.fa.rep_m10_b10_r1_c2_success.png
xmv_FTL1_ss.fa_vs_FTL1_pa.fa.rep_m10_r10_l1_c1_success.png

respectively.
